#!/usr/bin/env bash
#panel路径
PanelPath="/jd/panel"
 
#判断panel文件夹是否存在，若不存在，复制/jd目录内
if [[ ! -d "$PanelPath" ]]; then
 echo "控制面板已和谐，重新拷贝面板目录..."
 cp -r /jd/config/panel /jd/
 echo "启动控制面板挂载程序..."
 pm2 stop /jd/panel/server.js
 pm2 start /jd/panel/server.js
else
 echo "控制面板还存在."
fi





echo -e "======================== 增加重置密码功能 ========================\n"
sed -i '/一次性运行所有jd_scripts脚本/i\## 重置密码\nreset_user_password () {\n    cp -f $file_auth_sample $file_auth_user\n    echo -e "控制面板重置成功，用户名：admin，密码：adminadmin\\n"\n}\n' /jd/jtask.sh
sed -i '/runall)/i\            resetpwd)\n                reset_user_password\n                ;;' /jd/jtask.sh

echo -e "======================== 启动网页终端 ========================\n"
PIDS=`ps -ef|grep "ttyd"|grep -v grep`
if [ "$PIDS" = "" ]; then
    rm -rf /root/.pm2/logs/* 2>/dev/null  # 清空pm2日志
    if [[ $ENABLE_WEB_PANEL == true ]]; then
        if [[ $ENABLE_TTYD == true ]]; then
            ## 增加环境变量
            export PS1="\u@\h:\w $ "
            pm2 start ttyd --name="ttyd" -- -t fontSize=14 -t disableLeaveAlert=true -t rendererType=webgl bash
            if [[ $? -eq 0 ]]; then
                echo -e "网页终端启动成功...\n"
            else
                echo -e "网页终端启动失败，但容器将继续启动...\n"
            fi
        elif [[ $ENABLE_TTYD == false ]]; then
            echo -e "已设置为不自动启动网页终端，跳过...\n"
        fi
    else
        echo -e "已设置为不自动启动控制面板，因此也不启动网页终端...\n"
    fi
else
    echo -e "网页终端正在运行中...\n"
fi

echo -e "======================== 启动控制面板 ========================\n"
if [[ $ENABLE_WEB_PANEL == true ]]; then
    PIDS=`ps -ef|grep "server"|grep -v grep`
    if [ "$PIDS" = "" ]; then
        cd ${JD_DIR}/panel
        pm2 start ecosystem.config.js
        if [[ $? -eq 0 ]]; then
            echo -e "控制面板启动成功...\n"
            echo -e "如未修改用户名密码，则初始用户名为：admin，初始密码为：adminadmin\n"
            echo -e "请访问 http://<ip>:5678 登陆并修改配置...\n"
        else
            echo -e "控制面板启动失败，但容器将继续启动...\n"
        fi
    else
        echo -e "控制面板正在运行中...\n"
    fi
elif [[ $ENABLE_WEB_PANEL == true ]]; then
    echo -e "已设置为不自动启动控制面板，跳过...\n"
fi
